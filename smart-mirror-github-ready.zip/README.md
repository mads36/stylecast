
# Smart Mirror Pretotype

This is a simple pretotype for a Smart Mirror system that allows users to:
- Virtually try on outfits using augmented reality (AR)
- Receive fashion suggestions based on weather, occasion, and personal preferences

## Files Included
- index.html : Main file for the app interface

## How to Use
1. Clone this repository.
2. Open `index.html` in any browser to test the basic prototype.
3. You can also deploy this on GitHub Pages, Netlify, or Vercel for live preview.

---
Created as part of a Project-Based Learning assessment.
